/**********************************************************************
 postal.h

 Interface for the alternate mailer.

 Functions should return 0 on success, -1 on failure.

 Copyright 1997 Netscape Communications Corporation, all rights reserved.
**********************************************************************/

#ifndef __postal_h
#define __postal_h

extern int RegisterMailClient(void);
extern int UnRegisterMailClient(void);
extern int OpenMailSession(void* reserved1, void* reserved2);
extern int CloseMailSession(void);
extern int ComposeMailMessage(void* reserved, char* to, char* org, 
							  char* subject, char* body, char* cc, char* bcc);
extern int ShowMailBox(void);
extern int ShowMessageCenter(void);
extern char* GetMenuItemString(void);
extern char* GetNewsMenuItemString(void);
extern int HandleNewsUrl(char* url);

#endif
